import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/layout'

/**
 * Note: sub-menu only appear when route children.length >= 1
 * Detail see: https://panjiachen.github.io/vue-element-admin-site/guide/essentials/router-and-nav.html
 *
 * hidden: true                   if set true, item will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu
 *                                if not set alwaysShow, when item has more than one children route,
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noRedirect           if set noRedirect will no redirect in the breadcrumb
 * name:'router-name'             the name is used by <keep-alive> (must set!!!)
 * meta : {
    roles: ['admin','editor']    control the page roles (you can set multiple roles)
    title: 'title'               the name show in sidebar and breadcrumb (recommend set)
    icon: 'svg-name'/'el-icon-x' the icon show in the sidebar
    breadcrumb: false            if set false, the item will hidden in breadcrumb(default is true)
    activeMenu: '/example/list'  if set path, the sidebar will highlight the path you set
  }
 */

/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 */
export const constantRoutes = [
  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },

  {
    path: '/404',
    component: () => import('@/views/404'),
    hidden: true
  },

  {
    path: '/',
    component: Layout,
    redirect: '/dashboard',
    children: [{
      path: 'dashboard',
      name: '欢迎页',
      component: () => import('@/views/dashboard/index'),
      meta: { title: '欢迎页', icon: 'dashboard'}
    }]
  },

  {
    path: '/reader',
    component: Layout,
    redirect: '/reader/adminList',
    name: '读者管理',
    meta: { title: '读者管理', icon: 'el-icon-s-help' },
    children: [
      {
        path: 'adminList',
        name: '管理员名单',
        component: () => import('@/views/reader/admin'),
        meta: { title: '管理员名单', icon: 'table' }
      },
      {
        path: 'list',
        name: '读者列表',
        component: () => import('@/views/reader/list'),
        meta: { title: '读者列表', icon: 'table' }
      },
      {
        path: 'form',
        name: '读者添加',
        component: () => import('@/views/reader/form'),
        meta: { title: '读者添加', icon: 'form' }
      },
      {
        path: '/editReader/:id',
        name: '读者修改',
        component: () => import('@/views/reader/form'),
        meta: { title: '读者修改'},
        hidden:true
      }
    ]
  },

  {
    path: '/book',
    component: Layout,
    redirect: '/book/list',
    name: '图书管理',
    meta: { title: '图书管理', icon: 'el-icon-s-help' },
    children: [
      {
        path: 'list',
        name: '图书列表',
        component: () => import('@/views/book/list'),
        meta: { title: '图书列表', icon: 'table' }
      },
      {
        path: 'form',
        name: '图书添加',
        component: () => import('@/views/book/form'),
        meta: { title: '图书添加', icon: 'form' }
      },
      {
        path: '/edit/:id',
        name: '图书修改',
        component: () => import('@/views/book/form'),
        meta: { title: '图书修改'},
        hidden:true
      },
      {
        path: '/editRecord/:id',
        name: '借书记录添加',
        component: () => import('@/views/book/formRecord'),
        meta: { title: '借书记录添加'},
        hidden:true
      }
    ]
  },

  {
    path: '/record',
    component: Layout,
    redirect: '/record/list',
    name: '借书记录管理',
    meta: { title: '借书记录管理', icon: 'el-icon-s-help' },
    children: [
      {
        path: 'list',
        name: '记录列表',
        component: () => import('@/views/record/list'),
        meta: { title: '记录列表', icon: 'table' }
      },
      {
        path: 'form',
        name: '记录添加',
        component: () => import('@/views/record/form'),
        meta: { title: '记录添加', icon: 'form' }
      },
      {
        path: '/editRecord2/:id',
        name: '记录修改',
        component: () => import('@/views/record/form'),
        meta: { title: '记录修改'},
        hidden:true
      }
    ]
  },

  // 404 page must be placed at the end !!!
  { path: '*', redirect: '/404', hidden: true }
]

const createRouter = () => new Router({
  // mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRoutes
})

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router
